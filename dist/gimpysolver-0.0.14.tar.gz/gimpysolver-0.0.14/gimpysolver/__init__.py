"""
Captcha solver to SEACE Portal Scraper
The model have a 92% Accuracy.
"""
#from gimpysolver import captcha_solver

__version__ = "0.0.8"
__author__ = 'César Cortez'
__credits__ = 'Digitalia Tec'